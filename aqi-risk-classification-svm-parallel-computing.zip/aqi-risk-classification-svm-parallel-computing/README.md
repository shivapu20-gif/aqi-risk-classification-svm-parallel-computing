# Aqi Risk Classification Svm Parallel Computing

## Project Summary

Machine learning and parallel computing project classifying urban air quality risk using SVM and parallelised hyperparameter tuning in R.

## Tools Used

- Python / R
- Machine Learning
- Data Analysis
- Dashboarding / NLP / Parallel Computing (project dependent)

## What This Project Proves

This project demonstrates practical technical problem-solving, analytical thinking,
data preparation, modelling, reporting, and communication skills relevant to modern
data and analytics roles.

## Screenshots to Include

- Dashboard overview
- Workflow diagram
- Model results
- Key charts or outputs

## How to Run

1. Clone the repository
2. Open notebooks or scripts
3. Install required dependencies
4. Run analysis

## Limitations

- Academic project scope
- Some datasets may require manual download
- Some reports may require redaction before public sharing

## Future Improvements

- Better deployment
- Interactive dashboards
- Improved automation
- Additional model comparisons
